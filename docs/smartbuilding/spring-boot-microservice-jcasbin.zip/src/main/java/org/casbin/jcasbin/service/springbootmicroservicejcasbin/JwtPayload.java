package org.casbin.jcasbin.service.springbootmicroservicejcasbin;

public class JwtPayload {

	private String sub;

    private String name;

    private String iat;

    public String getSub ()
    {
        return sub;
    }

    public void setSub (String sub)
    {
        this.sub = sub;
    }

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    public String getIat ()
    {
        return iat;
    }

    public void setIat (String iat)
    {
        this.iat = iat;
    }

    @Override
    public String toString()
    {
        return "JWTProperties [sub = "+sub+", name = "+name+", iat = "+iat+"]";
    }
}

package org.casbin.jcasbin.service.springbootmicroservicejcasbin;

/**
 * 
 * @author phun
 * This is a POJO class for the JWT token from Smool Server
 * 
 * eyJhbGciOiJub25lIiwidHlwIjoiSldUIn0.eyJzdWIiOiJFbmFjdENvbnN1bWVyIiwib2JqIjoiQmxpbmRQb3NpdGlvbkFjdHVhdG9yIiwiYWN0Ijoid3JpdGUiLCJpYXQiOjE1OTc3NTE1NzEsImV4cCI6MTU5Nzc1MjE3MX0.
 * 
 * Decrypted data
{
 alg: "none",
 typ: "JWT"
}.
{
 sub: "EnactConsumer",
 obj: "BlindPositionActuator",
 act: "write",
 iat: 1597751571,
 exp: 1597752171
}.
[signature]
 *
 */

public class JwtPayload {

	private String sub;

    private String obj;
    
    private String act;

    private String iat;
    
    private String exp;

    public String getSub ()
    {
        return sub;
    }

    public void setSub (String sub)
    {
        this.sub = sub;
    }
    
    public String getIat ()
    {
        return iat;
    }

    public void setIat (String iat)
    {
        this.iat = iat;
    }

    @Override
    public String toString()
    {
        return "JWTProperties [sub = "+sub+", obj = "+obj+", act = "+act+", iat = "+iat+ ", exp = "+exp+"]";
    }

	public String getExp() {
		return exp;
	}

	public void setExp(String exp) {
		this.exp = exp;
	}

	public String getObj() {
		return obj;
	}

	public void setObj(String obj) {
		this.obj = obj;
	}

	public String getAct() {
		return act;
	}

	public void setAct(String act) {
		this.act = act;
	}
}

package org.casbin.jcasbin.service.springbootmicroservicejcasbin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMicroserviceJcasbinApplicationTests {

	@Test
	void contextLoads() {
	}

}

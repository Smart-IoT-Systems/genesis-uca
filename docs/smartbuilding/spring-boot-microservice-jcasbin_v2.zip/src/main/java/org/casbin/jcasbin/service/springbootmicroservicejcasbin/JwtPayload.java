package org.casbin.jcasbin.service.springbootmicroservicejcasbin;

/**
 * 
 * @author phun
 * This is a POJO class for the JWT token from Smool Server
 * 
 * eyJhbGciOiJub25lIiwidHlwIjoiSldUIn0.eyJzdWIiOiJFbmFjdENvbnN1bWVyNTQ5NiIsIm5hbWUiOiJwLCBFbmFjdENvbnN1bWVyLCBCbGluZFBvc2l0aW9uQWN0dWF0b3IsIHdyaXRlIiwiaWF0IjoxNTk2MDMwNDU0LCJleHAiOjE1OTYwMzEwNTR9.
 * 
 * Decrypted data
 * 	{
 alg: "none",
 typ: "JWT"
}.
{
 sub: "EnactConsumer5496",
 name: "p, EnactConsumer, BlindPositionActuator, write",
 iat: 1596030454,
 exp: 1596031054
}.
[signature]
 *
 */

public class JwtPayload {

	private String sub;

    private String name;

    private String iat;
    
    private String exp;

    public String getSub ()
    {
        return sub;
    }

    public void setSub (String sub)
    {
        this.sub = sub;
    }

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    public String getIat ()
    {
        return iat;
    }

    public void setIat (String iat)
    {
        this.iat = iat;
    }

    @Override
    public String toString()
    {
        return "JWTProperties [sub = "+sub+", name = "+name+", iat = "+iat+ ", exp = "+exp+"]";
    }

	public String getExp() {
		return exp;
	}

	public void setExp(String exp) {
		this.exp = exp;
	}
}
